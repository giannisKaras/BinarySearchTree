public class BinarySearchTree {
    public static boolean contains(Node root, int value){
        if(root.value == value){
            return true;
        }
        else if(root.value < value){
            if(root.right != null){
                return contains(root.right, value);
            }
            else
                return false;
        }
        else{
            if(root.left != null){
                return contains(root.left, value);
            }
            else
                return false;
        }
    }
}
